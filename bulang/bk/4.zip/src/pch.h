#ifndef PCH_H
#define PCH_H

#include <string.h>
#include <stddef.h>
#include <cstddef> // for std::nullptr_t
#include <cstdio>

//#include <cstring>
//#include <cstdint>
//#include <cstdlib>


#include <stdarg.h>


#include <stdexcept>
#include <vector>
#include <unordered_map>
#include <map>
#include <memory>
#include <string>
#include <algorithm>
#include <math.h>

#include <cassert>
#include <time.h>
#include <climits>

#endif // PCH_H
